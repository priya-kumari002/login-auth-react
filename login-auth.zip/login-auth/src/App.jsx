import { useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import StudentsPage from './pages/StudentsPage';
import Sidebar from './components/Sidebar';

function App() {
  

  return (
    <>
      <Router>
      <Sidebar />
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/students" component={StudentsPage} />
      </Switch>
    </Router>
        
    </>
  )
}

export default App
