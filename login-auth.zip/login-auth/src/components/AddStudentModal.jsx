// src/components/AddStudentModal.js
import React, { useState } from 'react';

const AddStudentModal = ({ onAddStudent }) => {
  const [student, setStudent] = useState({
    name: '',
    class: '',
    section: '',
    rollNumber: '',
    // add 8 more fields here
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudent((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddStudent(student);
  };

  return (
    <div>
      <h3>Add Student</h3>
      <form onSubmit={handleSubmit}>
        {/* Add 12 input fields */}
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={student.name}
          onChange={handleChange}
        />
        {/* Add other inputs for student details */}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default AddStudentModal;
