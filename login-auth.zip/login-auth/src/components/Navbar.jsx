// src/components/Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom';
import { auth } from '../firebase';

const Sidebar = () => {
  const handleLogout = () => {
    auth.signOut();
  };

  return (
    <div>
      <ul>
        <li>
          <Link to="/students">Students Page</Link>
        </li>
        <li>
          <button onClick={handleLogout}>Logout</button>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
