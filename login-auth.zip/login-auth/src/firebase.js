// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAUoCEGb4vH2coZ3p-TdIWuUEA6HI1F96w",
  authDomain: "mystic-stream-432718-g2.firebaseapp.com",
  projectId: "mystic-stream-432718-g2",
  storageBucket: "mystic-stream-432718-g2.firebasestorage.app",
  messagingSenderId: "777523016974",
  appId: "1:777523016974:web:1bb939db1d25dcb4d3935f",
  measurementId: "G-C4PXSKKNRB"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);